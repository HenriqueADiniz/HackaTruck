//
//  iMarketApp.swift
//  iMarket
//
//  Created by iMarketGroup on Junho/23.
//

import SwiftUI

@main
struct iMarketApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}

