



/*
  // Carregamento inicial
  ler os apiSupermecados do JSON
  ler os apiProdutos do JSON
 
  gerar arrays supermercados e produtos
  ir add ao supermercado correspondente

  
  ao clicar nas categorias: listar as categorias
  ao selecionar categoria: for nos produtos, if na categoria selecionada (e if do duplicado)
  ao selecionar um produto: add array produtosSelecionados
  ao clicar em finalizar: for nos supermecados com while existir nos produtos somaTotal = somaTotal + produto.preco
  ao clicar no supermercado: for no supermercado.produtos if no nome produto e salvar com o preco
*/

